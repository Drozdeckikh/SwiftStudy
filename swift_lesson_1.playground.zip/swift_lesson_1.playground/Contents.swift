import SwiftUI

let name = "Victor"
let family = "Simenko"
let age = 25
let growth = 175
let weight = 67

print("ФИО| \(name) \(family) \n\nAge| \(age)  Weight| \(weight) Growth| \(growth)")
